package com.rabbitmq.rabbitmqwork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(RabbitmqworkApplication.class, args);
	}

}
