package com.rabbitmq.rabbitmqwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitmqworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
