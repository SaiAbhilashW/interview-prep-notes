package com.rabbitmqapp.listener;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListenerApplicationTests {

	@Test
	void contextLoads() {
	}

}
